#pragma once
#include "VertexUI/VertexUI.min.h"
#include "VertexUI/VertexUI.Window.hpp"
#include "VertexUI/VertexUI.Control.hpp"
#include <any>

std::map<std::wstring, std::function<void()>>vinaFuncMap = {

{std::wstring(L"NIUZHI"), []()->void {
	
}},

{std::wstring(L""), []()->void {
}}
} ;