#pragma once
#include "framework.h"
namespace VertexUI {
	class VertexUIAnimation {

	};
}